//
//  AppDelegate.h
//  LZEasemobV2
//
//  Created by nacker on 2021/2/26.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,EMChatManagerDelegate>
{
    EMConnectionState _connectionState;
}


@property (strong, nonatomic) UIWindow *window;

@end

