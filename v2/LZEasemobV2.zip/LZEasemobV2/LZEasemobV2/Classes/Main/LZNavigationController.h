//
//  LZNavigationController.h
//  LZEasemobV2
//
//  Created by nacker on 2021/2/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZNavigationController : QMUINavigationController

@end

NS_ASSUME_NONNULL_END
