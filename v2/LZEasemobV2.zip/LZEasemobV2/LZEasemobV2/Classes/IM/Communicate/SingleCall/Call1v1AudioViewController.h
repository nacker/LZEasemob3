//
//  Call1v1AudioViewController.h
//  ChatDemo-UI3.0
//
//  Created by XieYajie on 2018/9/19.
//  Copyright © 2018 XieYajie. All rights reserved.
//

#import "EM1v1CallViewController.h"

@interface Call1v1AudioViewController : EM1v1CallViewController

@end
