//
//  CallSettingViewController.h
//  ChatDemo-UI3.0
//
//  Created by XieYajie on 06/12/2016.
//  Copyright © 2016 XieYajie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CallSettingViewController : UITableViewController

@end
