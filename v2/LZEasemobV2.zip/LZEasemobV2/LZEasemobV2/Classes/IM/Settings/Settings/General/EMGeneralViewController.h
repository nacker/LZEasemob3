//
//  EMGeneralViewController.h
//  EaseIM
//
//  Updated by zhangchong on 2020/6/10.
//  Copyright © 2018 XieYajie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMRefreshViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface EMGeneralViewController : EMRefreshViewController

@end

NS_ASSUME_NONNULL_END
