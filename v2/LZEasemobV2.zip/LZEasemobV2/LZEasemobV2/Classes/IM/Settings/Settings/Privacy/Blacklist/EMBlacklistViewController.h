//
//  EMBlacklistViewController.h
//  ChatDemo-UI3.0
//
//  Created by XieYajie on 2018/12/27.
//  Copyright © 2018 XieYajie. All rights reserved.
//

#import "EMSearchViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface EMBlacklistViewController : EMSearchViewController

@end

NS_ASSUME_NONNULL_END
