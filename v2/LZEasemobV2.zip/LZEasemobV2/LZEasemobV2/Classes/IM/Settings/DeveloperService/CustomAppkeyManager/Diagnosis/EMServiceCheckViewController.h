//
//  EMServiceCheckViewController.h
//  ChatDemo-UI3.0
//
//  Created by EaseMob on 2017/12/5.
//  Copyright © 2017年 EaseMob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EMServiceCheckViewController : UIViewController

@end
