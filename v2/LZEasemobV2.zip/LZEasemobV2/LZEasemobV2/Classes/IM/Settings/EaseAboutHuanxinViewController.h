//
//  EaseAboutHuanxinViewController.h
//  EMiOSDemo
//
//  Created by 娜塔莎 on 2020/3/18.
//  Copyright © 2020 zmw. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EaseAboutHuanxinViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
