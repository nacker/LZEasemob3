//
//  EMContactModel.m
//  EaseIMK
//

#import "EMContactModel.h"

@implementation EMContactModel
- (NSString *)easeId {
    return _huanXinId;
}

- (UIImage *)defaultAvatar {
    return _avatar;
}

- (NSString *)showName {
    return _nickname;
}
@end
